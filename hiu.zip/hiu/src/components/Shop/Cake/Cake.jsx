// src/components/Shop/Cake/Cake.jsx
import React, { useState } from "react";
import ImgCake from "../../../assets/Web/p3.png";

const CakesData = [
  {
    id: 1,
    img: ImgCake,
    name: "Chocolate Cake",
    aosDelay: "100",
    description: "A moist and decadent chocolate cake layered with rich chocolate ganache and topped with chocolate shavings.",
    ingredients: ["Flour", "Sugar", "Cocoa powder", "Eggs", "Butter", "Chocolate"],
  },
  {
    id: 2,
    img: ImgCake,
    name: "Vanilla Cake",
    aosDelay: "300",
    description: "A classic vanilla cake made with real vanilla beans and topped with a light vanilla buttercream frosting.",
    ingredients: ["Flour", "Sugar", "Vanilla beans", "Eggs", "Butter", "Milk"],
  },
  {
    id: 3,
    img: ImgCake,
    name: "Strawberry Cake",
    aosDelay: "500",
    description: "A light and fluffy cake infused with fresh strawberries and topped with strawberry cream.",
    ingredients: ["Flour", "Sugar", "Strawberries", "Eggs", "Butter", "Cream"],
  },
  {
    id: 4,
    img: ImgCake,
    name: "Red Velvet Cake",
    aosDelay: "700",
    description: "A rich and velvety cake with a hint of cocoa and cream cheese frosting.",
    ingredients: ["Flour", "Sugar", "Cocoa powder", "Eggs", "Butter", "Cream cheese"],
  },
];

const Cake = ({ onProductClick }) => {
  const [showMore, setShowMore] = useState(false);

  // Số lượng sản phẩm hiển thị mặc định
  const defaultDisplayCount = 3;

  return (
    <div className="py-10">
      <div className="container">
        <div className="text-center mb-20">
          <h1 className="text-4xl font-bold font-cursive text-gray-800">
            Cakes For You
          </h1>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-y-20 gap-x-5 place-items-center">
          {CakesData.slice(0, showMore ? CakesData.length : defaultDisplayCount).map((cake) => (
            <div
              key={cake.id}
              data-aos="fade-up"
              data-aos-delay={cake.aosDelay}
              className="rounded-2xl bg-white hover:bg-primary hover:text-white relative shadow-xl duration-high group max-w-[300px]"
              onClick={() => onProductClick(cake)}
            >
              <div className="h-[122px] relative">
                <img
                  src={cake.img}
                  alt={cake.name}
                  className="max-w-[200px] block mx-auto transform -translate-y-14 group-hover:scale-105 group-hover:rotate-6 duration-300"
                />
              </div>
              <div className="p-4 text-center">
                <div className="w-full"></div>
                <h1 className="text-xl font-bold">{cake.name}</h1>
                <p className="text-gray-500 group-hover:text-white duration-high text-sm line-clamp-2">
                  {cake.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-4">
          <button
            onClick={() => setShowMore(!showMore)}
            className="text-primary hover:text-primary-dark underline"
          >
            {showMore ? "Show Less" : "View More"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Cake;
