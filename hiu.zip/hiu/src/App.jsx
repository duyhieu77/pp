import React, { useEffect, useState } from 'react';
import AOS from 'aos';
import "aos/dist/aos.css";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar/Navbar';
import Home from './components/Home/Home';
import Services from './components/Services/Services';
import Testimonial from './components/Testimonial/Testimonial';
import Footer from './components/Footer/Footer';
import Login from './components/Register/Login';
import Registers from './components/Register/Register';
import Cake from './components/Shop/Cake/Cake';
import Coffee from './components/Shop/Drink/Coffee';
import OtherDrink from './components/Shop/Drink/OtherDrink';
import Marchandise from './components/Shop/Marchandise';
import Modal from "./components/Modal";
import Cookie from './components/Shop/Cake/Cookie';
const App = () => {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const handleProductClick = (product) => {
    setSelectedProduct(product);
  };

  const handleClose = () => {
    setSelectedProduct(null);
  };
  
  useEffect(() => {
    AOS.init({
      offset: 100,
      duration: 700,
      easing: "ease-in",
      delay: 100,
    });
  }, []);

  function NotFound() {
    return <h1>404 - Not Found</h1>;
  };

  return (
    <BrowserRouter>
      <div className="overflow-x-hidden">
        <Navbar />
        <Routes>
          <Route path="/" element={<>
            <Home />
            <Services />
            <Testimonial />
           
          </>} />
          <Route path="/login" element={<Login />} />
          <Route path='/register' element={<Registers/>} />
          <Route path="/shop/cake" element={<><Cake onProductClick={handleProductClick} /> <Cookie onProductClick={handleProductClick} /> </>} />
          <Route path="/shop/coffee" element={<><Coffee onProductClick={handleProductClick} /> <OtherDrink onProductClick={handleProductClick} /></>} />          
          <Route path="/shop/marchandise" element={<Marchandise />} />
          <Route path="*" element={<NotFound />} />
          {/* Các tuyến đường khác */}
        </Routes>
        <Modal product={selectedProduct} onClose={handleClose} />
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
